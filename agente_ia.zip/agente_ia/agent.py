from nearai.agents.environment import Environment, ToolRegistry
import requests

# Herramienta para llamar a función de crear wallet
def call_create_wallet(address: str):
    """Crea una wallet para el usuario
    Args:
        address: Es la dirección de la wallet elegida (e.g. si address = alice, entonces alice.near)
    Returns:
        Un diccionario con campos address, publicKey y privateKey
    """
    response = {
        "address": address,
        "publicKey": "1228732189372",
        "privateKey": "kjsdhfkiwerweor"
    }

    if response['address']:
        message = f'La creación fue exitosa esta en el siguiente address: {address}.near'
    else:
        message = "Error al crear, vuelvalo a intentar"
    return message

# Herramienta para llamar a función de agregar un producto en la plataforma
def call_add_product(producto: str, cantidad: int, categoria: str, peso: int, precio: int):
    """
    Args:
        producto: Nombre del producto a añadir
        cantidad: Cantidad del producto que se esta añadiendo
        categoria: Categoria del producto que se quiere añadir
        peso: Peso del producto ofrecido a vender
        precio: Precio del producto puesto en el servicio
    Returns:
        Un diccionario con un mensaje de confirmación de registro
    """
    response = {
        "code_status": "200",
        "message": "El codigo fue implementado correctamente"
    }
    if response['code_status'] == 200:
        message = response["message"]
    else:
        message = "Error al intentar añadir al catálogo"
    return message

# Herramienta para iniciar sesion
def call_log_in(num_tef: str):
    """
    Args:
        num_tef: Numero de telefono que valide la identidad y propiedad de las credenciales del usuario
    Returns:
        Un diccionario de validación de inicio de sesión
    """
    response = {
        "code_status": "200",
        "message": "El código fue implementado correctamente"
    }
    if response['code_status'] == 200:
        message = response['message']
    else:
        message = "Error al iniciar sesión con las credeciales dadas"
    return response


# Main entrypoint
def run(env: Environment):

    messages = env.list_messages()

    tools_registry = env.get_tool_registry(new=True)
    tools_registry.register_tool(call_create_wallet)
    tools_registry.register_tool(call_add_product)

    prompt = {
        "role": "system",
        "content": """
        Eres un asistente útil de ia de la startup GreenChain, una solución que
        se encarga de crear puentes digitales que eliminan intermediaros entre los agricultores peruanos
        y usuarios finales interesados en alimentos organicos y de origen natural.

        Posees acceso a 2 diferentes funciones fundamentales que cubren los casos de uso del chatbot:
            -> Crear cuenta
            -> Agregar productos al catálogo

        Durante un saludo se le ofrece a un usuario estas 3 funciones enumeradas, en las que puede ingresar o el nombre de la función
        que sea ejecutar o el número asociado a esta.
        En caso que llame a crear cuenta, entonces se le solicita al usuario que pueda ingresar un nombre con el cual generar la cuenta y se llama
        a la herramienta apropiada para esta tarea, ademas se devuelve el contenido de esta formateado para que el usuario pueda entenderlo.

        En caso que llame a agregar productos al catálogo, entonces se le solicita al usuario ingresar una serie de parámetros como:
            - producto: Nombre del producto a añadir
            - cantidad: Cantidad del producto que se esta añadiendo
            - categoria: Categoria del producto que se quiere añadir
            - peso: Peso del producto ofrecido a vender
            - precio: Precio del producto puesto en el servicio
        Si es que faltase valores, solicitarselo al usuario y llamar a la herramienta más adecuado

        Recuerda de que todas las soluciones dadas necesitan ser formateadas para el usuario apartir del texto en formato JSON obtenido desde
        el backend, usa un lenguaje amigable que le haga ver que la operacion fue correcta
        """
    }

    response = env.completions_and_run_tools([prompt] + messages, tools=tools_registry.get_all_tool_definitions())
    # env.add_reply(response)

run(env)
